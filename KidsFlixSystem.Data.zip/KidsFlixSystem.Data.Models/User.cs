﻿namespace KidsFlixSystem.Data.Models
{
    using Microsoft.AspNetCore.Identity;
    using Microsoft.EntityFrameworkCore;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using static KidsFlixSystem.Common.EntityValidationConstants.User;
    public class User : IdentityUser<Guid>
    {
        public User()
        {
            this.Reviews = new List<Review>();
        }

        [Key]
       public int UserId { get; set; }
        [Required]
        [MaxLength(UserNameMaxLength)]
        [Comment("User name")]
        public string Name { get; set; } = string.Empty;

        [Required]
        [MaxLength(UserPasswordMaxLength)]
        [Comment("Password for the user")]
        public string Password { get; set; } = string.Empty;


        [Required]
        [Comment("The role of user")]
        public string UserRole { get; set; } = string.Empty;

        public virtual ICollection<Review> Reviews { get; set; } = new List<Review>();
    }
}
