﻿namespace KidsFlixSystem.Data.Models
{
    using System.ComponentModel.DataAnnotations.Schema;
    using System.ComponentModel.DataAnnotations;

    using static KidsFlixSystem.Common.EntityValidationConstants.Review;
    using Microsoft.AspNet.Identity.EntityFramework;

    public class Review
    {
        [Key]
        public int Id { get; set; }  

        [MaxLength(ReviewCommentMaxLength)]
        public string Comment { get; set; } = string.Empty;
        [Required]
        public DateTime DateCreated { get; set; }
        [Required]
        public int MovieId { get; set; }
        [ForeignKey(nameof(MovieId))]
        public Movie Movie { get; set; } = null!;
        [Required]
        public Guid UserId { get; set; }
        [ForeignKey(nameof(UserId))]
        public User User { get; set; } = null!;
        

      
    }
}
