﻿namespace KidsFlixSystem.Common
{
	public static class GeneralApplicationConstants
	{
		public const int ReleaseYear = 2024;
	}
}
