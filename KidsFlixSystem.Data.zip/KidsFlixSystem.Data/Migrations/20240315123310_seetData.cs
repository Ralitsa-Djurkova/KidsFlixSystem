﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace KidsFlixSystem.Data.Migrations
{
    public partial class seetData : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Directors",
                columns: new[] { "Id", "Biography", "DiteOfBirth", "FullName", "PhotoUrl" },
                values: new object[,]
                {
                    { 1, "American director, producer, writer, animator, and voice actor.", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified).AddTicks(1957), "Brat Luis", "https://upload.wikimedia.org/wikipedia/commons/3/3a/Brad_bird_cropped_2009.jpg" },
                    { 2, "is an American animator, character designer, story artist, film director, producer, and screenwriter. He is best known as the director of the Walt Disney Animation Studios films Bolt (2008), Tangled (2010), Zootopia (2016), and Encanto (2021). He is the first LGBT director to win the Oscar for Best Animated Feature twice for his work on Zootopia and Encant", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified).AddTicks(1968), "Bayron Howard", "https://upload.wikimedia.org/wikipedia/commons/9/99/Byron_Howard.jpg" }
                });

            migrationBuilder.InsertData(
                table: "Movies",
                columns: new[] { "Id", "Description", "DirectorId", "Duration", "Genre", "Rating", "ReleaseDate", "Title", "TrailerUrl" },
                values: new object[,]
                {
                    { 1, "A rat who can cook makes an unusual alliance with a young kitchen worker at a famous Paris restaurant.", 0, 111, "Comedy", 8.0999999999999996, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified).AddTicks(2007), "Ratatouille", "https://www.imdb.com/title/tt0382932/" },
                    { 2, "n the city of Zootopia, a rookie bunny police officer named Judy Hopps teams up with a cynical fox con artist named Nick Wilde to solve a mysterious case involving the disappearance of predators. Along the way, they uncover a conspiracy that challenges the harmony of their diverse animal society.", 0, 106, "Comedy", 8.5, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified).AddTicks(2016), "Zootopia", "https://www.imdb.com/title/tt2948356/" }
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Directors",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Directors",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Movies",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Movies",
                keyColumn: "Id",
                keyValue: 2);
        }
    }
}
